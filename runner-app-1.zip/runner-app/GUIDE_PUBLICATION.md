# Publier Runner 2D en application Android

Contenu du dossier :
- `site/` : le jeu prêt à l'emploi (index.html, manifeste, mode hors ligne, icônes, politique de confidentialité)
- `store/` : icône 512, image de présentation 1024×500, 4 captures d'écran, textes de la fiche
- `capacitor/` : plan B (projet Android Studio, il faut un PC)

Ce qui est testé : le jeu se charge sans erreur dans Chromium, le mode hors ligne s'installe et le manifeste est valide.
Ce qui n'est PAS testé : la génération du fichier Android (.aab). Je n'avais pas accès au kit Android depuis mon environnement.

## Étape 1 – Mettre le jeu en ligne (gratuit, faisable depuis le téléphone)

Il faut une adresse https qui sert le dossier `site/`. Le plus simple : GitHub Pages.
1. Crée un compte sur github.com, puis un dépôt public (ex. `runner2d`).
2. Envoie TOUT le contenu de `site/` à la racine du dépôt (bouton « Add file » → « Upload files »). Garde les dossiers `icons/` et le fichier `.nojekyll`.
3. Réglages du dépôt → Pages → Source : « Deploy from a branch », branche `main`, dossier `/ (root)`.
4. Après 1-2 minutes, ton jeu est sur `https://TON-PSEUDO.github.io/runner2d/`.
5. Ouvre cette adresse dans Chrome sur ton S25 : menu ⋮ → « Installer l'application ». Tu as déjà une vraie appli sur ton téléphone, sans passer par le Play Store.

Avant d'envoyer : ouvre `site/confidentialite.html` et remplace `[TON ADRESSE E-MAIL ICI]` par une adresse de contact.

## Étape 2 – Créer le fichier pour le Play Store avec PWABuilder

1. Va sur pwabuilder.com et colle l'adresse de ton jeu.
2. Clique « Package for stores » → Android → « Google Play ».
3. Réglages : identifiant de paquet de type `com.tonnom.runner2d` (définitif, impossible à changer après), nom « Runner 2D », version 1, affichage plein écran, orientation paysage.
4. Signature : choisis « New » (PWABuilder crée la clé). Télécharge le zip.
5. Dans le zip : le fichier `.aab` (à envoyer au Play Store), le fichier de clé `.keystore` et ses mots de passe, et un `assetlinks.json`.
   GARDE le `.keystore` et ses mots de passe en lieu sûr : sans eux tu ne pourras plus mettre à jour l'appli.
6. Pour que l'appli s'ouvre sans barre d'adresse : ajoute dans ton dépôt un fichier `.well-known/assetlinks.json` (contenu du fichier du zip).
   Si tu actives « Play App Signing » (recommandé), utilise aussi l'empreinte SHA-256 donnée par la Play Console (Configuration → Intégrité de l'appli) : tu peux mettre les deux empreintes dans le même fichier.

## Étape 3 – Play Console

1. Crée un compte développeur sur play.google.com/console (frais uniques d'environ 25 $, vérification d'identité demandée).
2. « Créer une application » → jeu, gratuit.
3. Fiche : copie les textes de `store/fiche-play-store.md`, ajoute `icone-play-store-512.png`, `image-de-presentation-1024x500.png` et les 4 captures.
4. Politique de confidentialité : l'adresse de `confidentialite.html` sur ton site.
5. Questionnaire de classification et « Sécurité des données » : réponses suggérées dans `store/fiche-play-store.md`.
6. Envoie le `.aab` dans un test interne d'abord, installe-le sur ton S25, vérifie, puis passe en production.
7. Vérifie les règles actuelles de Google pour les comptes personnels récents : un test fermé avec un nombre minimum de testeurs pendant environ 14 jours peut être exigé avant la production.

## Mettre à jour le jeu plus tard
1. Remplace `site/index.html` dans le dépôt.
2. Dans `site/sw.js`, change `VERSION='runner-v1'` en `runner-v2` (sinon les joueurs gardent l'ancienne version hors ligne).
3. Comme l'appli charge le jeu depuis ton site, les joueurs reçoivent la mise à jour sans nouvelle version du Play Store.

## Points d'attention
- Droits d'auteur : Google refuse les applis qui copient des personnages existants. Vérifie que tu as le droit d'utiliser tous les sprites (Coureuse, J2, zombies, Survivant). Le Survivant ressemble beaucoup à un personnage de jeu vidéo connu : utilise des images dont tu es l'auteur ou licenciées.
- Nom du jeu : « Runner 2D » est un nom provisoire très générique. Change-le dans `site/manifest.webmanifest` et dans `<title>` de `site/index.html` (30 caractères max sur le Play Store).
- Multijoueur : le bouton « Wi-Fi local » est un vrai mode SANS internet : les deux téléphones (même Wi-Fi ou partage de connexion) se scannent deux QR codes. Le scan utilise la caméra et le lecteur de QR de Chrome sur Android ; sinon, un code texte est proposé en secours. Le jeu demande l’autorisation de la caméra avant le scan. Une fois connectés, les joueurs arrivent dans un salon (pseudos, 0 à 2 IA, map de départ choisie par l’hôte). Le parcours est identique pour les deux joueurs. Testé entre deux navigateurs sur ordinateur, pas encore sur deux vrais téléphones.
- Partie en ligne : elle passe par des serveurs publics gratuits (bibliothèque Trystero) et demande internet. Pas de salon public ni de classement.
- Mode solo : jouable hors ligne.


## Tutoriel
Au premier lancement (et via Réglages > Revoir le tutoriel), le jeu propose une course d'entraînement guidée : sauter, glisser, plateforme, caisse « ? », meuble, tir, grappin, sprint, zombies. Chaque étape se valide en réussissant l'action ; « PASSER » permet de l'ignorer.
