# Plan B : projet Android Studio (PC requis, non testé)

Cette méthode emballe le jeu directement dans l'appli (aucun site à héberger, tout est hors ligne sauf le multijoueur).

1. Installe Node.js et Android Studio sur un PC.
2. Dans ce dossier `capacitor/` : `npm install`, puis `npx cap add android`, puis `npx cap sync android`.
3. Ouvre le dossier `android/` créé dans Android Studio (`npx cap open android`).
4. Dans `android/app/src/main/AndroidManifest.xml`, ajoute à la balise `<activity>` : `android:screenOrientation="sensorLandscape"`.
5. Remplace les icônes : clic droit sur `app` → New → Image Asset, avec `site/icons/icon-512.png`.
6. Menu Build → Generate Signed App Bundle → Android App Bundle : crée une clé (garde-la précieusement) et génère le `.aab` à envoyer sur la Play Console.
7. Change `appId` dans `capacitor.config.json` avant l'étape 2 : c'est l'identifiant définitif de ton appli.

Pour mettre à jour le jeu : remplace `site/index.html`, puis `npx cap sync android` et génère un nouvel `.aab` avec un numéro de version plus élevé.
