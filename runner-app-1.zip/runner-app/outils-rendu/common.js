import * as THREE from 'three';import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
// Couleurs par zone. beard : barbe (bas du visage) ; gloves : mains de la couleur ACC ; sleeves : bras d'une autre couleur que le torse
export const CFG={
 survivant:{file:'survivant.glb',SKIN:'#c99474',HAIR:'#3a2a20',TOP:'#5b3a24',ARMS:'#5b3a24',PANTS:'#2f3a4e',BOOT:'#2b2018',BELT:'#1e1712',beard:2},
 speedster:{file:'speedster.glb',SKIN:'#e0ad8a',HAIR:'#c79a52',TOP:'#1f3b8f',ARMS:'#1f3b8f',PANTS:'#1f3b8f',BOOT:'#e8b923',BELT:'#e8b923',ACC:'#e8b923',gloves:1},
 lastsurvivor:{file:'lastsurvivor.glb',SKIN:'#cf9a76',HAIR:'#6e4e32',TOP:'#3c4034',ARMS:'#8a2f2a',PANTS:'#3d5170',BOOT:'#4a3426',BELT:'#2a1f18',beard:1},
 zombie:{file:'zombie.glb',tex:1}};
export async function setup(name,tint){const C0=CFG[name];
 const g=await new GLTFLoader().loadAsync(C0.file);const root=g.scene;let mesh;root.traverse(o=>{if(o.isSkinnedMesh)mesh=o});mesh.frustumCulled=false;
 if(C0.tex){if(tint)mesh.material.color=new THREE.Color(tint)}
 else{const bones=mesh.skeleton.bones.map(b=>b.name),geo=mesh.geometry,pos=geo.attributes.position,n=pos.count,ji=geo.attributes.skinIndex,wi=geo.attributes.skinWeight;
  const dom=new Int32Array(n);for(let i=0;i<n;i++){let best=0,bw=-1;for(let s=0;s<4;s++){const w=wi.getComponent(i,s);if(w>bw){bw=w;best=ji.getComponent(i,s)}}dom[i]=best}
  // boîte de la tête pour situer visage / barbe / cheveux
  const hb={x0:9,x1:-9,y0:9,y1:-9,z0:9,z1:-9};for(let i=0;i<n;i++){if(!/Head/.test(bones[dom[i]]))continue;const x=pos.getX(i),y=pos.getY(i),z=pos.getZ(i);hb.x0=Math.min(hb.x0,x);hb.x1=Math.max(hb.x1,x);hb.y0=Math.min(hb.y0,y);hb.y1=Math.max(hb.y1,y);hb.z0=Math.min(hb.z0,z);hb.z1=Math.max(hb.z1,z)}
  const hh=hb.y1-hb.y0,hw=Math.max(-hb.x0,hb.x1),C={};for(const k of ['SKIN','HAIR','TOP','ARMS','PANTS','BOOT','BELT','ACC'])if(C0[k])C[k]=new THREE.Color(C0[k]);
  const col=new Float32Array(n*3);
  for(let i=0;i<n;i++){const nm=bones[dom[i]]||'',x=pos.getX(i),y=pos.getY(i),z=pos.getZ(i);let c;
   if(/Head|head|neck/.test(nm)){const yy=(y-hb.y0)/hh,front=z>hb.z1*.3,mid=Math.abs(x)<hw*.56;
    if(yy<.2&&z>hb.z0*.6)c=C.SKIN;else if(front&&mid&&yy<.8){c=(C0.beard&&yy<(C0.beard===2?.36:.42))?C.HAIR:C.SKIN}else c=C.HAIR}
   else if(/Hand|Thumb|Index|Middle|Ring|Pinky/.test(nm))c=C0.gloves?C.ACC:C.SKIN;
   else if(/Foot|Toe/.test(nm))c=C.BOOT;else if(/Leg/.test(nm))c=y<0.32?C.BOOT:C.PANTS;
   else if(/Hips/.test(nm))c=y>0.98?C.BELT:C.PANTS;else if(/Arm/.test(nm))c=C.ARMS;else c=C.TOP;
   col[i*3]=c.r;col[i*3+1]=c.g;col[i*3+2]=c.b}
  geo.setAttribute('color',new THREE.BufferAttribute(col,3));mesh.material=new THREE.MeshStandardMaterial({vertexColors:true,roughness:.72,metalness:0})}
 const sc=new THREE.Scene();sc.add(new THREE.HemisphereLight('#fff6e8','#3a3530',1.15));const k=new THREE.DirectionalLight('#fff3df',2.5);k.position.set(-1.2,2.6,3);sc.add(k);
 const rim=new THREE.DirectionalLight('#9fc8ff',1.4);rim.position.set(2.2,1.2,-2);sc.add(rim);const f=new THREE.DirectionalLight('#ffd9b0',.45);f.position.set(1,.3,2);sc.add(f);
 sc.add(root);root.rotation.y=Math.PI/2;
 const mix=new THREE.AnimationMixer(root),hips=root.getObjectByName('Hips'),h0=hips.position.clone(),clips={};for(const c of g.animations)clips[c.name]=c;
 // Roulade : ces modèles n'en ont pas, on reprend celle de la Coureuse (même squelette Meshy, os liés par leur nom)
 if(!C0.tex&&!clips.Run_Jump_and_Roll){const gc=await new GLTFLoader().loadAsync('coureuse.glb'),src=gc.animations.find(c=>c.name=='Run_Jump_and_Roll'),hy=gc.scene.getObjectByName('Hips').position.y,k=h0.y/hy,cl=src.clone();
  cl.tracks=cl.tracks.filter(t=>root.getObjectByName(t.name.split('.')[0]));for(const t of cl.tracks)if(t.name=='Hips.position')for(let i=0;i<t.values.length;i++)t.values[i]*=k;clips.Run_Jump_and_Roll=cl}
 let cur=null;
 function pose(name,t,lock){if(cur!==name){mix.stopAllAction();mix.clipAction(clips[name]).reset().play();cur=name}mix.setTime(t);
  if(lock!==false){hips.position.x=h0.x;hips.position.z=h0.z;if(lock==='y')hips.position.y=h0.y}root.updateMatrixWorld(true)}
 return {THREE,root,mesh,sc,mix,hips,h0,clips,pose,bone:n=>root.getObjectByName(n)}}
