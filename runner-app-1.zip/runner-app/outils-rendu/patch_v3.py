import sys, base64
SRC = '/home/claude/v3/src/runner-app/site/index.html'
OUT = '/home/claude/v3/out/index.html'
s = open(SRC, encoding='utf-8').read()

def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        sys.exit('MATCH %d != %d : %s' % (n, count, old[:100]))
    s = s.replace(old, new)

atlas = 'data:image/webp;base64,' + base64.b64encode(open('/home/claude/v3/render/missile_atlas.webp', 'rb').read()).decode()
block = open('/home/claude/v3/missile.js', encoding='utf-8').read().replace('__MSL_ATLAS__', atlas)

# 1. Nouveau bloc missile, avant fogOpp
rep("function fogOpp(){if(MP)atk('brume');", block + "function fogOpp(){if(MP)atk('brume');")

# 2. Tir du joueur : missile au lieu de la balle
rep("P.gun=.4;P.ga=ga;later(.12,()=>{const h0=phd('aim'),mx=(h0?h0.x:P.x+10)+Math.cos(ga)*20,my=(h0?h0.y:P.y-44)+Math.sin(ga)*20;noise(.1,.25,2200);shots.push({x:mx,y:my,vx:Math.cos(ga)*600,vy:Math.sin(ga)*600,t:0,tg,bt})})",
    "P.gun=.5;P.ga=ga;later(.12,()=>mslFire(ga,tg,bt))")

# 3. Vol et impact des missiles du joueur
rep("for(const h of shots){h.t+=dt;const[tx,ty]=tpos(h.tg,h.bt),dx=tx-h.x,dy=ty-h.y,n=Math.hypot(dx,dy)||1,k=Math.min(1,7*dt);h.vx+=(dx/n*640-h.vx)*k;h.vy+=(dy/n*640-h.vy)*k;h.x+=h.vx*dt;h.y+=h.vy*dt;\n  if(n<24){h.dead=1;s.bonus+=20;if(h.tg=='ai'){{const bb=h.bt||a;if(!MP&&bb.shield>0)bb.shield=0;else{if(MP)hitEnt(bb,'hit',0);else bb.stun=.2}}}else zPush(45);boom(h.x)}if(h.t>3)h.dead=1}",
    "for(const h of shots){const[tx,ty]=tpos(h.tg,h.bt),n=mslStep(h,dt,tx,ty,h.t>.8?14:6.5,780);\n  if(n<22){h.dead=1;s.bonus+=20;mslBoom(h.x,h.y,1);if(h.tg=='ai'){if(!h.vis){const bb=h.bt||a;if(!MP&&bb.shield>0){bb.shield=0;rings.push({x:bb.x,t:0})}else if(MP)hitEnt(bb,'hit',0);else{bb.stun=.6;bb.down=.4}}}else zPush(70)}\n  else if(h.t>3.2||h.x<-90||h.x>W+140){h.dead=1;if(h.t>3.2)mslBoom(h.x,h.y,0)}}")

# 4. Missiles ennemis (IA / autre joueur) : virage lent, esquivables
rep("for(const h of shots2){h.x-=700*dt;if(Math.abs(h.x-P.x)<12&&Math.abs(h.y-(P.y-36))<40){h.dead=1;if(!blocked()){s.slow=.2;s.shake=6}}if(h.x<-20)h.dead=1}",
    "for(const h of shots2){mslStep(h,dt,P.x,P.y-46,h.t<.45?2.4:1.15,560);const top=P.y-((P.sl>0&&P.on)||s.down>0?40:72);\n  if(Math.abs(h.x-P.x)<17&&h.y>top-3&&h.y<P.y+2){h.dead=1;mslBoom(h.x,h.y,1);if(!blocked()){s.slow=.35;s.down=.35;s.shake=9;s.gap-=20;vib([60,30,60])}}\n  else if(h.t>3.6||h.x<-90||h.x>W+150){h.dead=1;if(h.x>-60&&h.x<W+60)mslBoom(h.x,h.y,0)}}")
rep("shots2=shots2.filter(h=>!h.dead)", "shots2=shots2.filter(h=>!h.dead);mslFxUpd(dt)")

# 5. L'IA tire un missile vers le joueur
rep("else if(it=='tir'&&ah){a.gun=.4;a.ga=Math.PI;later(.12,()=>{shots2.push({x:a.x,y:P.y-36});noise(.1,.2,2200)});ok=1}",
    "else if(it=='tir'&&ah){a.gun=.5;a.ga=Math.atan2(P.y-46-(a.y-44),P.x-(a.x-10));later(.14,()=>{if(!a.out&&state=='play')enemyMsl(a.x-10+Math.cos(a.ga)*22,a.y-44+Math.sin(a.ga)*22,a.ga)});ok=1}")

# 6. Réseau : le joueur visé voit arriver le missile et peut l'esquiver
rep(" if(t=='furn')throwFurn(H0,P.x+Math.max(x,90),1);", " if(t=='msl'){if(state=='play'&&!st.endT)incomingMsl(H0);return}\n if(t=='furn')throwFurn(H0,P.x+Math.max(x,90),1);")
rep("function botHit(b,t){if(b.out)return;if(t=='hit')b.stun=.2;", "function botHit(b,t){if(b.out)return;if(t=='hit'){b.stun=.6;b.down=.4}")
rep("if(t=='hit'){st.slow=.2;st.gap-=25;st.shake=8}", "if(t=='hit'){st.slow=.35;st.down=.35;st.gap-=25;st.shake=8;mslBoom(P.x,P.y-40,1)}")

# 7. Dessin : fumée sous les persos, missiles + explosions par-dessus
rep(" for(const h of shots){ctx.save();ctx.globalCompositeOperation='lighter';ctx.lineCap='round';ctx.strokeStyle='rgba(255,200,90,.55)';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(h.x-h.vx*.05,h.y-h.vy*.05);ctx.lineTo(h.x,h.y);ctx.stroke();ctx.strokeStyle='#fff6cf';ctx.lineWidth=2.4;ctx.beginPath();ctx.moveTo(h.x-h.vx*.02,h.y-h.vy*.02);ctx.lineTo(h.x,h.y);ctx.stroke();ctx.restore()}", " smkDraw();")
rep("for(const h of shots2){for(let i=3;i>0;i--){ctx.globalAlpha=.16*(4-i);ctx.fillStyle='#ff9a3c';ctx.beginPath();ctx.arc(h.x+i*9,h.y,6-i,0,7);ctx.fill()}ctx.globalAlpha=1;ctx.fillStyle='#ff9a3c';ctx.beginPath();ctx.arc(h.x,h.y,6,0,7);ctx.fill()}", "")
rep(" thrDraw();burstDraw();", " thrDraw();burstDraw();for(const h of shots)mslDraw(h);for(const h of shots2)mslDraw(h);blastDraw();")

# 8. Lance-missile en main (joueur, IA, et pendant la visée)
rep("if(P.gun>0){const h=phd('aim');gunDraw(P.x,P.y,h?h.ang:(P.ga||0),.4-P.gun,h)}", "if(P.gun>0){const h=phd('aim');launcherDraw(P.x,P.y,h?h.ang:(P.ga||0),.5-P.gun,h,P.gun>.38)}")
rep("for(const b of AIs)if(!b.out&&b.gun>0)gunDraw(b.x,b.y,b.ga===undefined?Math.PI:b.ga,.4-b.gun);", "for(const b of AIs)if(!b.out&&b.gun>0&&b.x>-40&&b.x<W+40)launcherDraw(b.x,b.y,b.ga===undefined?Math.PI:b.ga,.5-b.gun,null,b.gun>.36);")
rep("else if(st.item=='tir'&&!(P.gun>0)){const h=phd('aim');gunDraw(P.x,P.y,h?h.ang:0,1,h)}", "else if(st.item=='tir'&&!(P.gun>0)){const h=phd('aim');launcherDraw(P.x,P.y,h?h.ang:0,1,h,1)}")

# 9. Bouton, nom, aide, sons, remise à zéro, téléport/échange
rep("case'tir':ctx.moveTo(-9,3);ctx.lineTo(4,-4);ctx.lineTo(9,-9);ctx.lineTo(7,2);ctx.lineTo(-3,7);ctx.closePath();ctx.fill();break;",
    "case'tir':if(MSL.ok){mslSprite(0,6,-.55,T*12,34);break}ctx.moveTo(-9,3);ctx.lineTo(4,-4);ctx.lineTo(9,-9);ctx.lineTo(7,2);ctx.lineTo(-3,7);ctx.closePath();ctx.fill();break;")
rep("tir:'#ff6b6b',", "tir:'#6d7fa3',")
rep("tir:'TIR',", "tir:'MISSILE',")
rep("st.item=='tir'?'Tape à droite : viser l’IA · à gauche : les zombies'", "st.item=='tir'?'Missile : tape un adversaire · à gauche : les zombies'")
rep("hit:()=>{noise(.25,.3,900);", "launch:()=>{noise(.45,.2,1700);tone(170,.42,'sawtooth',.07,560)},kaboom:()=>{noise(.75,.42,380);tone(85,.55,'sawtooth',.2,30)},hit:()=>{noise(.25,.3,900);")
rep("traps2=[];shots2=[];grens=[];", "traps2=[];shots2=[];smk=[];blasts=[];grens=[];")
rep("for(const a of [mons,plats,cranes,turns,boxes,traps,traps2,pads,oils,vents,forks,shots,shots2,fx,rings])", "for(const a of [mons,plats,cranes,turns,boxes,traps,traps2,pads,oils,vents,forks,shots,shots2,fx,rings,smk,blasts])")

import os
os.makedirs('/home/claude/v3/out', exist_ok=True)
open(OUT, 'w', encoding='utf-8').write(s)
print('ok', len(s))
