# Rendu des personnages (états SN + gestes SAL) et du zombie, au format du jeu
import http.server,threading,functools,base64,io,json,sys,math,os
from playwright.sync_api import sync_playwright
from PIL import Image,ImageFilter
OUT='/home/claude/v6/out';os.makedirs(OUT,exist_ok=True)
class Qh(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a):pass
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8812),functools.partial(Qh,directory='/home/claude/v6/render'))
threading.Thread(target=srv.serve_forever,daemon=True).start()
def lin(a,b,n):return [a+(b-a)*i/(n-1) for i in range(n)]
def specs_sn(D):
    S=[];idx={}
    def add(key,lst):idx[key]=list(range(len(S),len(S)+len(lst)));S.extend(lst)
    run=D['Running'];add('run',[dict(clip='Running',t=run*i/16) for i in range(16)])
    fa=D['RunFast'];add('fast',[dict(clip='RunFast',t=fa*i/12) for i in range(12)])
    j=D['Regular_Jump']
    if 'Unarmed_Vault' in D:v=D['Unarmed_Vault'];add('jv',[dict(clip='Unarmed_Vault',t=v*x/24,lock='y') for x in lin(3.4,9.6,10)])
    else:add('jv',[dict(clip='Regular_Jump',t=j*x/24,lock='y') for x in lin(8.3,13.8,10)])
    add('gr',[dict(clip='Regular_Jump',t=j*8/24,lock='y')])
    add('land',[dict(clip='Regular_Jump',t=j*x/24) for x in (15.2,16.6)])
    add('se',[dict(clip='Regular_Jump',t=j*x/24) for x in (2,2.8,3.6,4.3)])
    add('sl',[dict(clip='Regular_Jump',t=j*x/24) for x in (4.3,4.7,5.0,5.2,5.0,4.7)])
    s=D['slide_right'];add('bs',[dict(clip='slide_right',t=s*x/24) for x in (4.2,5.2,6.2,7.2)])
    add('bl',[dict(clip='slide_right',t=s*x/24) for x in (8,9,10,11,12,13)])
    add('ex',[dict(clip='slide_right',t=s*x/24) for x in (15,17.5,20)])
    add('lay',[dict(clip='slide_right',t=s*10/24)])
    if 'Run_Jump_and_Roll' in D:rr=D['Run_Jump_and_Roll'];add('rl',[dict(clip='Run_Jump_and_Roll',t=rr*x/24) for x in lin(13.2,22.5,14)])
    else:add('rl',[dict(clip='Regular_Jump',t=j*x/24) for x in lin(15.0,21.5,14)])
    for k in ('gr','lay'):idx[k]=idx[k][0]
    return S,idx
def specs_sal(D):
    S=[];idx={};run=D['Running']
    def add(key,lst):idx[key]=list(range(len(S),len(S)+len(lst)));S.extend(lst)
    for lp in range(3):add('aim%d'%lp,[dict(clip='Running',t=run*lp/3,arm=dict(k='aim',ang=q*math.pi/8)) for q in range(16)])
    add('lasso',[dict(clip='Running',t=run*i/4,arm=dict(k='p',u=[.25+.08*math.cos(i*1.57),.95,.2],f=[.2+.12*math.cos(i*1.57),1,.2])) for i in range(4)])
    add('cock',[dict(clip='Running',t=run*i/4,arm=dict(k='p',u=[-.45,-.75,.25],f=[-.3,.95,.2])) for i in range(4)])
    TH=[([-.6,.6],[-.25,1]),([.1,1],[.3,1]),([.8,.5],[.95,.3]),([.9,-.3],[.9,-.45])]
    add('th',[dict(clip='Running',t=0,arm=dict(k='p',u=u+[.2],f=f+[.2])) for u,f in TH])
    return S,idx
def specs_zom(D):
    S=[];idx={}
    def add(key,lst):idx[key]=list(range(len(S),len(S)+len(lst)));S.extend(lst)
    r=D['Running'];add('run',[dict(clip='Running',t=r*i/12) for i in range(12)])
    f=D['run_fast_8'];add('fast',[dict(clip='run_fast_8',t=f*i/12) for i in range(12)])
    return S,idx
def outline(im):
    a=im.split()[3];d=a.filter(ImageFilter.MaxFilter(3));o=Image.new('RGBA',im.size,(24,18,20,0));o.putalpha(d.point(lambda v:min(255,int(v*.85))));return Image.alpha_composite(o,im)
def pack(frames,hand,scale=2):
    cells=[]
    for f in frames:
        im=Image.open(io.BytesIO(base64.b64decode(f['png'].split(',')[1]))).convert('RGBA')
        im=im.resize((im.width//scale,im.height//scale),Image.LANCZOS);ax,ay=f['ax']/scale,f['ay']/scale
        im=outline(im);bb=im.split()[3].point(lambda v:255 if v>8 else 0).getbbox() or (0,0,1,1)
        x0,y0,x1,y1=bb;x0=max(0,x0-1);y0=max(0,y0-1);x1=min(im.width,x1+1);y1=min(im.height,y1+1)
        c=im.crop((x0,y0,x1,y1));e=[c,round(ax-x0,1),round(ay-y0,1)]
        if hand:e+=[round(f['hx']/scale-ax,1),round(f['hy']/scale-ay,1)]
        cells.append(e)
    MW=2048;x=y=rh=0;pos=[]
    for c in cells:
        w,h=c[0].size
        if x+w>MW:x=0;y+=rh+2;rh=0
        pos.append((x,y));x+=w+2;rh=max(rh,h)
    atlas=Image.new('RGBA',(MW,y+rh),(0,0,0,0));fr=[]
    for c,(px_,py_) in zip(cells,pos):atlas.paste(c[0],(px_,py_));fr.append([px_,py_,c[0].width,c[0].height]+c[1:])
    return atlas,fr
jobs=sys.argv[1].split(',')   # ex. survivant,speedster,lastsurvivor,zombie ; "preview" pour un aperçu
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for m in jobs:
        variants=[(None,'')] if m!='zombie' else [(None,''),('#9fb3a0','_b')]
        for tint,suf in variants:
            pg=b.new_page();pg.on('pageerror',lambda e:print('ERR',e))
            pg.goto('http://127.0.0.1:8812/frames.html?m='+m+('&tint='+tint.replace('#','%23') if tint else ''));pg.wait_for_function('window.done',timeout=120000)
            D=pg.evaluate('window.durs')
            sets=[('zs',specs_zom(D))] if m=='zombie' else [('sn',specs_sn(D)),('sal',specs_sal(D))]
            for name,(SP,idx) in sets:
                frames=[pg.evaluate('f=>renderFrame(f)',s) for s in SP]
                atlas,fr=pack(frames,name=='sal',3 if name=='zs' else 2)
                q=78 if name=='sal' else 82
                atlas.save(f'{OUT}/{m}{suf}_{name}.webp',quality=q,method=6);atlas.save(f'{OUT}/{m}{suf}_{name}.png')
                json.dump(dict(fr=fr,**idx),open(f'{OUT}/{m}{suf}_{name}.json','w'))
                print(m+suf,name,len(frames),atlas.size,os.path.getsize(f'{OUT}/{m}{suf}_{name}.webp')//1024,'Ko',flush=True)
            pg.close()
    b.close()
srv.shutdown()
