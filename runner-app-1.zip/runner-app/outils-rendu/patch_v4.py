import sys
F = '/home/claude/v3/out/index.html'   # sortie de patch_v3.py (lancer patch_v3.py juste avant)
s = open(F, encoding='utf-8').read()
if 'function botSnDraw' in s: sys.exit('déjà appliqué : relancer patch_v3.py d’abord')
def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count: sys.exit('MATCH %d != %d : %s' % (n, count, old[:100]))
    s = s.replace(old, new)

anim = open('/home/claude/v3/anim.js', encoding='utf-8').read()
# 1. Adversaires (IA, autres joueurs, coureur du menu) avec les personnages 3D
rep("function rival(x,y,ph,air,a){if(!(TH.spr&&RV.ok))return man(x,y,ph,air,a);",
    anim + "function rival(x,y,ph,air,a){{const si=botSkin(AI);if(si>=0)return botSnDraw(AI,x,y,a,si)}if(!(TH.spr&&RV.ok))return man(x,y,ph,air,a);")
# 2. Multijoueur : chacun envoie son personnage
rep("rm.presence({pid:PID,nm:nick(),host:h,", "rm.presence({pid:PID,nm:nick(),sk:SNOK()?SNI():-1,host:h,")
rep("rm.presence({lb:0,m:MID,dd:0,rd:1,", "rm.presence({sk:SNOK()?SNI():-1,lb:0,m:MID,dd:0,rd:1,")

# 3. Zombies : cadence un peu plus rapide, fondu entre deux images, petit rebond à chaque pas
rep("const ty=ZS.T[h.ty%ZS.T.length],n=ty.f.length,k=.85+(h.r-18)/14*.3,f=ty.f[n>1?((Math.floor(t*ty.s/7)%n)+n)%n:0],r=ZS.fr[f],U=ZS.U*k,b=n>1?0:Math.abs(Math.sin(t))*2.5;",
    "const ty=ZS.T[h.ty%ZS.T.length],n=ty.f.length,k=.85+(h.r-18)/14*.3,tf=t*ty.s*1.3/7,i0=Math.floor(tf),fq=tf-i0,f=ty.f[n>1?((i0%n)+n)%n:0],f2=ty.f[n>1?(((i0+1)%n)+n)%n:0],wq=n>1?Math.max(0,(fq-.55)/.45):0,w2=wq*wq*(3-2*wq),r=ZS.fr[f],r2=ZS.fr[f2],U=ZS.U*k,b=n>1?Math.pow(Math.abs(Math.sin(tf*Math.PI)),1.5)*1.8:Math.abs(Math.sin(t))*2.5;")
rep("ctx.scale(1/br,br);ctx.drawImage(ZS.img,r[0],r[1],r[2],r[3],-r[4]*U,-r[5]*U,r[2]*U,r[3]*U);ctx.restore()}",
    "ctx.scale(1/br,br);ctx.drawImage(ZS.img,r[0],r[1],r[2],r[3],-r[4]*U,-r[5]*U,r[2]*U,r[3]*U);ctx.restore()}")
open(F, 'w', encoding='utf-8').write(s)
print('ok', len(s))
