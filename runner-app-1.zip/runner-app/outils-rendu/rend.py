import http.server,threading,functools,sys
from playwright.sync_api import sync_playwright
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a):pass
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8811),functools.partial(Q,directory='/home/claude/v6/render'))
threading.Thread(target=srv.serve_forever,daemon=True).start()
page,out,w,h=sys.argv[1],sys.argv[2],int(sys.argv[3]),int(sys.argv[4])
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    pg=b.new_page(viewport={'width':w,'height':h});pg.on('pageerror',lambda e:print('ERR',e));pg.on('console',lambda m:print('LOG',m.text) if m.type in('error','warning') else None)
    pg.goto('http://127.0.0.1:8811/'+page);pg.wait_for_function('window.done',timeout=120000)
    print(pg.evaluate('window.anims||window.info||""'))
    pg.screenshot(path=out);b.close()
srv.shutdown()
