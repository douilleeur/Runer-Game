import sys, json, base64
F = '/home/claude/v3/out/index.html'   # sortie de patch_v6.py
s = open(F, encoding='utf-8').read()
if 'ROULADE_V7' in s: sys.exit('déjà appliqué')
def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count: sys.exit('MATCH %d != %d : %s' % (n, count, old[:100]))
    s = s.replace(old, new)
O = '/home/claude/v6/out/'; U = 0.318
def uri(f): return 'data:image/webp;base64,' + base64.b64encode(open(O + f, 'rb').read()).decode()
def sn(m):
    d = json.load(open(O + m + '_sn.json')); d['U'] = U; d['cyc'] = 6.0; d['fcy'] = 7.5
    return 'SNL.push(snMk(%s,%r));' % (json.dumps(d, separators=(',', ':')), uri(m + '_sn_q.webp'))
def sal(m):
    d = json.load(open(O + m + '_sal.json')); fr = d.pop('fr')
    return 'SAL.push(snMk(%s,%r));' % (json.dumps({'fr': fr, 'idx': d, 'U': U, 'cyc': 6.0}, separators=(',', ':')), uri(m + '_sal_q.webp'))
# 1. Atlas des 3 personnages refaits : vraie roulade (reprise de la Coureuse) à l'atterrissage
a = s.index('// PERSOS_V6'); b = s.index('const SNMAP={0:0,1:1,2:2,3:3};')
blk = s[a:b]; lines = blk.split('\n')
head = [l for l in lines if not l.startswith('SNL.push(') and not l.startswith('SAL.push(')]
pushes = [l for l in lines if l.startswith('SNL.push(') or l.startswith('SAL.push(')]
if len(pushes) != 4 or not pushes[0].count('SNL.push(') == 1: sys.exit('bloc persos : %d lignes' % len(pushes))
keep0 = pushes[0]   # Coureuse inchangée (SNL+SAL sur la même ligne)
new_pushes = [keep0] + [sn(m) + sal(m) for m in ('survivant', 'speedster', 'lastsurvivor')]
mk = [l for l in head if l.startswith('function snMk(')]
pre = [l for l in head if l and not l.startswith('function snMk(')]
s = s[:a] + '\n'.join(pre) + '\n' + '\n'.join(mk) + '\n' + '\n'.join(new_pushes) + '\n' + s[b:]
# 2. IA et autres joueurs : roulade aussi quand ils retombent d'un saut
rep("if(b.on&&b.pOn===0&&(b.pvy||0)>260)b.ldT=.17;b.pOn=b.on?1:0;b.pvy=vy;b.ldT=(b.ldT||0)-ldt;",
    "/*ROULADE_V7*/if(b.on&&b.pOn===0){if((b.pvy||0)>420&&SN.rl)b.rlT=.6;else if((b.pvy||0)>260)b.ldT=.17}b.pOn=b.on?1:0;b.pvy=vy;b.ldT=(b.ldT||0)-ldt;b.rlT=b.on?(b.rlT||0)-ldt:0;")
rep("else if(b.ldT>0)f=b.ldT>.08?SN.land[0]:SN.land[1];",
    "else if(b.rlT>0){const t=1-b.rlT/.6;f=SN.rl[Math.min(SN.rl.length-1,Math.floor(t*SN.rl.length))];rot=0}\n else if(b.ldT>0)f=b.ldT>.08?SN.land[0]:SN.land[1];")
open(F, 'w', encoding='utf-8').write(s)
print('ok', len(s))
