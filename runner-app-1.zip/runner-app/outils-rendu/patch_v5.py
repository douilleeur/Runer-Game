import sys, re, json, base64
F = '/home/claude/v3/out/index.html'   # sortie de patch_v4.py
s = open(F, encoding='utf-8').read()
if 'COUREUSE_V5' in s: sys.exit('déjà appliqué')
def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count: sys.exit('MATCH %d != %d : %s' % (n, count, old[:100]))
    s = s.replace(old, new)
O = '/home/claude/v5/out/'
U = 0.318
def uri(name): return 'data:image/webp;base64,' + base64.b64encode(open(O + name + '.webp', 'rb').read()).decode()
def sn(pal):
    m = json.load(open(O + pal + '_sn.json')); m['U'] = U; m['cyc'] = 6.0; m['fcy'] = 7.5
    return 'SNL.push(snMk(%s,%r));' % (json.dumps(m, separators=(',', ':')), uri(pal + '_sn'))
def sal():
    m = json.load(open(O + 'base_sal.json')); fr = m.pop('fr')
    d = {'fr': fr, 'idx': m, 'U': U, 'cyc': 6.0}
    return 'SAL.push(snMk(%s,%r));' % (json.dumps(d, separators=(',', ':')), uri('base_sal'))

# 1. Remplace les 5 anciens personnages 3D (états + gestes) par la nouvelle Coureuse + 3 tenues d'adversaires
a = s.index('const SNL=[],SAL=[];'); b = s.index('const SNMAP=')
block = s[a:b]
mk = block[block.index('function snMk('):]; mk = mk[:mk.index('\n') + 1]
new = ('// COUREUSE_V5 : modèle 3D animé (Meshy) rendu en images. SNL[0] = toi, SNL[1..3] = tenues des adversaires ; SAL[0] = gestes d\'objets\n'
       'const SNL=[],SAL=[];\n' + mk + sn('base') + sal() + '\n' + sn('b1') + '\n' + sn('b2') + '\n' + sn('b3') + '\n')
s = s[:a] + new + s[b:]
rep("const SNMAP={0:1,2:4,4:3,5:0,6:2};", "const SNMAP={0:0};")
# 2. Un seul personnage jouable
rep("if(CHAR>6)CHAR=0;", "CHAR=0;")
rep("${charSection()}${trailSection()}", "${trailSection()}")
# 3. Images des anciens personnages retirées (le code reste, il n'est plus utilisé)
n0 = len(s)
s, k = re.subn(r"(?<![A-Za-z])(SV|CK|BZ|SP|SPR)\.img\.src='data:[^']+'", r"0/*\1 retiré*/", s)
if k != 5: sys.exit('images anciens persos : %d' % k)
# 4. Course rapide pendant le sprint
rep("else{const n=SN.run.length;f=SN.run[((Math.floor(ph/SN.cyc*n)%n)+n)%n]}",
    "else if(st.boost>0&&SN.fast){const n=SN.fast.length;f=SN.fast[((Math.floor(ph/(SN.fcy||7.5)*n)%n)+n)%n]}else{const n=SN.run.length;f=SN.run[((Math.floor(ph/SN.cyc*n)%n)+n)%n]}")
open(F, 'w', encoding='utf-8').write(s)
print('ok', n0, '->', len(s))
