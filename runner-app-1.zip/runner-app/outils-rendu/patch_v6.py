import sys, re, json, base64
F = '/home/claude/v3/out/index.html'   # sortie de patch_v5.py
s = open(F, encoding='utf-8').read()
if 'PERSOS_V6' in s: sys.exit('déjà appliqué')
def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count: sys.exit('MATCH %d != %d : %s' % (n, count, old[:100]))
    s = s.replace(old, new)
O = '/home/claude/v6/out/'
U = 0.318
def uri(f): return 'data:image/webp;base64,' + base64.b64encode(open(O + f, 'rb').read()).decode()
def sn(m):
    d = json.load(open(O + m + '_sn.json')); d['U'] = U; d['cyc'] = 6.0; d['fcy'] = 7.5
    return 'SNL.push(snMk(%s,%r));' % (json.dumps(d, separators=(',', ':')), uri(m + '_sn_q.webp'))
def sal(m):
    d = json.load(open(O + m + '_sal.json')); fr = d.pop('fr')
    return 'SAL.push(snMk(%s,%r));' % (json.dumps({'fr': fr, 'idx': d, 'U': U, 'cyc': 6.0}, separators=(',', ':')), uri(m + '_sal_q.webp'))
CH = ['coureuse', 'survivant', 'speedster', 'lastsurvivor']

# 1. Quatre personnages jouables (0 Coureuse, 1 Survivant, 2 Speedster, 3 Dernier Survivant)
a = s.index('// COUREUSE_V5'); b = s.index('const SNMAP={0:0};') + len('const SNMAP={0:0};')
blk = s[a:b]; mk = blk[blk.index('function snMk('):]; mk = mk[:mk.index('\n') + 1]
new = ('// PERSOS_V6 : modèles 3D animés (Meshy) rendus en images. SNL[i] = états du personnage i, SAL[i] = ses gestes d\'objets\n'
       'const SNL=[],SAL=[];\n' + mk + '\n'.join(sn(m) + sal(m) for m in CH) + '\nconst SNMAP={0:0,1:1,2:2,3:3};')
s = s[:a] + new + s[b:]
rep("catch(e){}CHAR=0;", "catch(e){}if(!(CHAR>=0&&CHAR<=3))CHAR=0;")
rep("${trailSection()}", "${charSection()}${trailSection()}")
i = s.index("function charSection(){return"); j = s.index('\n', i)
s = s[:i] + ("function charSection(){const N=['Coureuse','Survivant','Speedster','Dernier Survivant'];return`<p style=\"margin:0 0 6px;color:#9aa4bd\">Personnage</p>`+N.map((n,i)=>`<div style=\"display:flex;align-items:center;justify-content:space-between;margin:6px 0;padding:8px;border-radius:8px;background:#1b2030\"><span style=\"display:flex;align-items:center;gap:10px\">${SNL[i]&&SNL[i].ok?snThumb(i):''}${n}</span><button style=\"${BS};background:${CHAR==i?'#2b6b4f':'#3a4a9f'}\" onclick=\"charUse(${i})\">${CHAR==i?'Choisi':'Choisir'}</button></div>`).join('')}") + s[j:]

# 2. Zombies : modèle 3D animé (2 courses x 2 teintes), jambes calées sur la distance parcourue
zj = json.load(open(O + 'zombies.json'))
m = re.search(r"const ZS=Object\.assign\(\{ok:0,img:new Image\(\)\},\{.*?\}\);\s*ZS\.img\.onload=\(\)=>\{ZS\.ok=1\};ZS\.img\.src='data:[^']+'", s, re.S)
if not m: sys.exit('ZS')
s = s[:m.start()] + ("const ZS=Object.assign({ok:0,img:new Image()},%s,{U:0.44});ZS.img.onload=()=>{ZS.ok=1};ZS.img.src=%r" % (json.dumps(zj, separators=(',', ':')), uri('zombies.webp'))) + s[m.end():]
i = s.index('function zomS('); j = s.index("document.addEventListener('visibilitychange'", i)
s = s[:i] + """function zomS(x,h,t){if(!ZS.ok)return zom(x,h.r/26,t);
 const ty=ZS.T[h.ty%ZS.T.length],n=ty.f.length,k=.88+(h.r-18)/14*.24,ph=((st?st.dist:0)/18+h.dx*.37)/ty.cy*n,f=ty.f[((Math.floor(ph)%n)+n)%n],r=ZS.fr[f],U=ZS.U*k;
 const gy=rampTop(x),dg=Math.max(0,Math.min(1,1-st.gap/260)),hp=st.hh>0?Math.sin(Math.PI*Math.max(0,Math.min(1,(.55-st.hh)*2-(h.dx%40)/160)))*13:0;
 ctx.fillStyle='rgba(0,0,0,'+.3*(1-hp/26)+')';ctx.beginPath();ctx.ellipse(x,gy+1,17*k*(1-hp/40),4.2*k,0,0,7);ctx.fill();
 ctx.save();ctx.translate(x,gy-hp);ctx.rotate(.02+dg*.12+Math.sin(t*1.7)*.02);ctx.drawImage(ZS.img,r[0],r[1],r[2],r[3],-r[4]*U,-r[5]*U,r[2]*U,r[3]*U);ctx.restore()}
""" + s[j:]

# 3. Horde : sa propre vitesse (course normale). Qui ralentit se fait rattraper, qui sprinte la distance.
rep(" if(s.zOn)s.gap=Math.min(gmax()+Math.max(0,BX-spread()[0]),s.gap+(18-s.time*.5)*dt);",
    " if(s.zOn){const vz=Math.min(260+s.time*6,520)*.97;if(!TUT)s.gap+=(v-vz)*dt;s.gap=Math.min(gmax()+Math.max(0,BX-spread()[0]),s.gap+(14-s.time*.5)*dt)}")
rep(" if(s.zOn&&s.boost>0)s.gap=Math.min(s.gap+v/3*dt,gmax()+Math.max(0,BX-spread()[0]));", "")
rep("s.blk=1;s.gap-=100*dt", "s.blk=1;s.gap-=40*dt", 2)
open(F, 'w', encoding='utf-8').write(s)
print('ok', len(s))
