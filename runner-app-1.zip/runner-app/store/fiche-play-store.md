# Fiche Play Store (à copier-coller)

**Nom (30 car. max)** : Runner 2D  *(provisoire)*

**Description courte (80 car. max)** :
Cours, saute, glisse : élimine l'IA avant que les zombies ne t'attrapent !

**Description complète** :
Une horde de zombies te poursuit : ne ralentis pas !

Affronte une IA redoutable dans une course de parkour effrénée. Le dernier rattrapé par les zombies perd : à toi de faire tomber ton adversaire dans la horde.

• Contrôles simples : swipe vers le haut pour sauter, vers le bas pour glisser sous les barres
• Caisses « ? » : meuble piège, missile téléguidé, grappin, double saut, huile, brouillard, bouclier, inversion, échange de place et plus encore
• Grappin avec balancement : accroche une grue, lâche au bon moment pour prendre de la vitesse
• Parkour : plateformes, rails, trampolines, pentes et changements de décor à chaque virage
• 5 environnements : ville, néon, désert, glace, immeuble
• Mode solo contre l'IA, course à 4 et multijoueur Wi-Fi local
• Missions du jour, succès, boutique (traînées de sprint, maps) et vibrations

Mode solo et jeu local à deux (QR code) jouables sans internet.

**Catégorie** : Jeux → Action  (tags : course, arcade, zombie)

**Classification (questionnaire IARC) – suggestion** : violence cartoon légère (zombies), pas de sang réaliste, pas d'achats, pas de publicité. Réponds honnêtement au questionnaire : c'est toi qui es responsable des réponses.

**Sécurité des données – suggestion** : aucune donnée collectée ni partagée par l'appli ; progression stockée uniquement sur l'appareil. Précise que le mode en ligne utilise une connexion réseau entre joueurs et que la caméra sert uniquement à scanner un QR code (rien n'est enregistré). Vérifie ces réponses toi-même avant de valider.

**Public cible** : 13 ans et plus (évite « moins de 13 ans » pour ne pas déclencher les règles famille).

**Prix** : gratuit, sans achats intégrés, sans publicité.
